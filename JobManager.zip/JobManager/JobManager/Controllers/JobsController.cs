﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using JobManager.Services;
using JobManager.Models;

namespace JobManager.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class JobsController : ControllerBase
    {

        private ILogger _logger;
        private IJobsService _service;


        public JobsController(ILogger<JobsController> logger, IJobsService service)
        {
            _logger = logger;
            
            _service = service;

        }

        [HttpGet("/api/jobs")]
        public ActionResult<List<JobDetails>> GetJobs()
        {   
            return _service.GetJobs();
        }

        [HttpPost("/api/jobs")]
        public ActionResult<JobDetails> AddJob([FromQuery(Name = "ids")]int[] ids)
        {
            return _service.CreateJob(ids);
             
        }

        [HttpGet("/api/products/{id}")]
        public ActionResult<JobDetails> GetJob(int id)
        {
            return _service.GetJob(id);
            
        }

       
    }
}

