﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JobManager.Models;

namespace JobManager.Services
{
    public interface IJobsService
    {
        List<JobDetails> GetJobs();

         JobDetails CreateJob(int[] jb);

         JobDetails GetJob(int id);

    }    
}
