﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JobManager.Models;

namespace JobManager.Services
{
    public class JobService : IJobsService
    {
        private List<JobDetails> _jobdetails;
        private int id = 0;
        public JobService()
        {
            _jobdetails = new List<JobDetails>();
        }

        
        public int GenerateId()
        {
            return id++;
        }

        public List<JobDetails> GetJobs()
        {
            return _jobdetails;
        }

        public JobDetails CreateJob(int[] jb)
        {
            int[] outputjobs;
            int[] inputjobs = jb;
            JobDetails _job = null; 
            
            if (jb != null && jb.Length > 0)
            {
                JobDetails _jb = new JobDetails()
                {
                    jobID = GenerateId(),
                    jobin = inputjobs,
                    jobStatus = "Pending",
                    CreatedTime = new DateTime(),
                    totalTime = 0


                };
                outputjobs = SortJobs(jb, 0, jb.Length - 1);
                if(outputjobs!=null && outputjobs.Length>0)
                {
                    _jb.totalTime = ((new DateTime() - _jb.CreatedTime).Seconds);
                    _jb.jobStatus = "Complete";
                    _jb.jobout = outputjobs;
                }
                _jobdetails.Add(_jb);


            }

            return _jobdetails[_jobdetails.Count-1];

        }

        private  int[] SortJobs(int[] jb, int left, int right)
        {
            int pivot, leftend, rightend;

            leftend = left;
            rightend = right;
            pivot = jb[left];

            while (left < right)
            {
                while ((jb[right] >= pivot) && (left < right))
                {
                    right--;
                }

                if (left != right)
                {
                    jb[left] = jb[right];
                    left++;
                }

                while ((jb[left] <= pivot) && (left < right))
                {
                    left++;
                }

                if (left != right)
                {
                    jb[right] = jb[left];
                    right--;
                }
            }
            return jb;
        }

        public JobDetails GetJob(int id)
        {
            JobDetails _jb = null;
            _jb = _jobdetails.Where(j => j.jobID == id).Select(jd => new JobDetails()
            {
                jobID = jd.jobID,
                jobin = jd.jobin,
                jobStatus = jd.jobStatus,
                CreatedTime = jd.CreatedTime,
                totalTime = jd.totalTime,
                jobout = jd.jobout
            }).FirstOrDefault<JobDetails>();
            return _jb;
        }

       
    }
}
