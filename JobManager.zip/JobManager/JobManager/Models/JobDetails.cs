﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JobManager.Models
{
    public class JobDetails
    {
        public int jobID { get; set; }

        public int[] jobin { get; set; }

        public DateTime CreatedTime { get; set; }


        public int totalTime { get; set; }


        public string jobStatus { get; set; }


        public int[] jobout { get; set; }



    }
}
